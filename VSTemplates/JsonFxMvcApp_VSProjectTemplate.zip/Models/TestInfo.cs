﻿using System;

namespace MyApp.Models
{
	public class TestInfo
	{
		public double Number
		{
			get;
			set;
		}

		public DateTime TimeStamp
		{
			get;
			set;
		}

		public string Machine
		{
			get;
			set;
		}
	}
}
