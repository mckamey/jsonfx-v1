using System;
using System.Web;

using JsonFx.Json;
using JsonFx.JsonRpc;

namespace $rootnamespace$
{
	[JsonService(Namespace="$rootnamespace$.$safeitemname$", Name="Proxy")]
	public class $safeitemname$
	{
		#region Init

		/// <summary>
		/// Ctor
		/// </summary>
		public $safeitemname$()
		{
		}

		#endregion Init

		#region Service Methods

		/// <summary>
		/// The proxy function will be $rootnamespace$.Jrpc.$safeitemname$.Proxy.helloWorld
		/// </summary>
		/// <param name="number">a number</param>
		/// <returns>Hello world</returns>
		[JsonMethod(Name="helloWorld")]
		public string HelloWorld(double number)
		{
			return "Hello world";
		}

		#endregion Service Methods
	}
}