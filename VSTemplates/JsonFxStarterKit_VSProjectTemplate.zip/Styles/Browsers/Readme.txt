These browser logos are protected by copyright and/or trademark.

It is believed that the use of low-resolution images of logos for certain uses involving
identification may qualify as fair use under United States copyright law.

Any other uses of this image, may be copyright infringement. Certain commercial use of this
image may also be trademark infringement.
