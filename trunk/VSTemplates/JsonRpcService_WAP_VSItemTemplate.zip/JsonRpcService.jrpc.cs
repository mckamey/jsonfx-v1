using System;
using System.Web;

using JsonFx.Json;
using JsonFx.JsonRpc;

namespace $rootnamespace$
{
	[JsonService(Namespace="MyApp", Name="$safeitemname$")]
	public class $safeitemname$
	{
		#region Init

		/// <summary>
		/// Ctor
		/// </summary>
		public $safeitemname$()
		{
		}

		#endregion Init

		#region Service Methods

		/// <summary>
		/// The proxy function will be MyApp.$safeitemname$.helloWorld()
		/// </summary>
		/// <param name="number">a number</param>
		/// <returns>Hello world</returns>
		[JsonMethod(Name="helloWorld")]
		public string HelloWorld(double number)
		{
			return "Hello world";
		}

		#endregion Service Methods
	}
}