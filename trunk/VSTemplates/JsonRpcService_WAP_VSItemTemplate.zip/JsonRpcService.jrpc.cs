using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;

using JsonFx.Json;
using JsonFx.JsonRpc;

namespace $rootnamespace$
{
	[JsonService(Namespace="MyApp", Name="$safeitemname$")]
	public class $safeitemname$
	{
		/// <summary>
		/// The proxy function will be MyApp.$safeitemname$.helloWorld() in JavaScript
		/// </summary>
		/// <param name="number">a number</param>
		/// <returns>Hello world</returns>
		[JsonMethod(Name="helloWorld")]
		public string HelloWorld(double number)
		{
			return "Hello world";
		}
	}
}